﻿INSERT INTO Historia (Titulo, Conteudo, Imagem)
VALUES (
    'História do FC Porto',
    'O Futebol Clube do Porto foi fundado a 28 de setembro de 1893, tornando-se um dos clubes mais antigos e bem-sucedidos de Portugal. Ao longo da sua história, o clube conquistou inúmeros títulos nacionais e internacionais, consolidando-se como um símbolo de excelência desportiva.

Conhecido pela sua cor azul e branca e pelo icónico dragão no emblema, o FC Porto tem uma tradição de desenvolver talentos locais e competir em alto nível nas competições europeias.

O clube viveu momentos marcantes, incluindo vitórias na Liga dos Campeões da UEFA, na Liga Europa e na Supertaça Europeia. A paixão dos adeptos e a força do Estádio do Dragão contribuíram para criar uma identidade forte e reconhecida internacionalmente.

Ao longo das décadas, treinadores e jogadores lendários ajudaram a construir a reputação do FC Porto, tornando-o um dos clubes mais respeitados de Portugal e da Europa.',
    '~/images/porto_historia.jpg'
);
GO
