﻿INSERT INTO Contactos (Tipo, Valor)
VALUES ('Email', 'info@fcporto.pt');
GO

INSERT INTO Contactos (Tipo, Valor)
VALUES ('Telefone', '+351 225 074 100');
GO

INSERT INTO Contactos (Tipo, Valor)
VALUES ('Morada', 'Estádio do Dragão, Via Futebol Clube do Porto, 4350-415 Porto, Portugal');
GO
