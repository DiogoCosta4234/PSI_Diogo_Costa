﻿INSERT INTO Estadio (Nome, Descricao, Imagem)
VALUES (
    'Estádio do Dragão',
    'Inaugurado em 2003, o Estádio do Dragão é a casa do Futebol Clube do Porto. Com capacidade para mais de 50.000 adeptos, é considerado um dos estádios mais modernos de Portugal.

O estádio recebe jogos da liga portuguesa, competições europeias e eventos especiais. Além disso, possui infraestruturas de topo, incluindo museu, lojas oficiais e zonas VIP.

O Estádio do Dragão é conhecido pela atmosfera incrível criada pelos adeptos do FC Porto, especialmente nos jogos mais importantes. O emblema do dragão e as cores azul e branco tornam a experiência única para qualquer visitante.

Além de futebol, o estádio é palco de concertos e eventos culturais, consolidando-se como um ponto de referência na cidade do Porto.',
    '~/images/estadio1.jpg'
);
GO
