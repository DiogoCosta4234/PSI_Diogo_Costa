﻿-- ===========================================
-- Criar a Base de Dados
-- ===========================================


USE fcporto;
GO

-- ===========================================
-- Tabela: Jogadores
-- ===========================================
CREATE TABLE Jogadores (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nome NVARCHAR(100) NOT NULL,
    Posicao NVARCHAR(50) NOT NULL,
    Imagem NVARCHAR(200) NOT NULL
);
GO

-- ===========================================
-- Tabela: Trofeus
-- ===========================================
CREATE TABLE Trofeus (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nome NVARCHAR(100) NOT NULL,
    Ano INT NOT NULL,
    Imagem NVARCHAR(200) NOT NULL
);
GO

-- ===========================================
-- Tabela: Historia
-- ===========================================
CREATE TABLE Historia (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Titulo NVARCHAR(100) NOT NULL,
    Conteudo NVARCHAR(MAX) NOT NULL,
    Imagem NVARCHAR(200) NULL
);
GO

-- ===========================================
-- Tabela: Estadio
-- ===========================================
CREATE TABLE Estadio (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nome NVARCHAR(100) NOT NULL,
    Descricao NVARCHAR(MAX) NOT NULL,
    Imagem NVARCHAR(200) NULL
);
GO

-- ===========================================
-- Tabela: Contactos
-- ===========================================
CREATE TABLE Contactos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Tipo NVARCHAR(50) NOT NULL,   -- Ex.: "Email", "Telefone", "Morada"
    Valor NVARCHAR(200) NOT NULL
);
GO

-- ===========================================
-- Inserir dados de exemplo
-- ===========================================

-- Jogadores
INSERT INTO Jogadores (Nome, Posicao, Imagem) VALUES
('José Sá', 'Guarda-Redes', '~/images/josesa.jpg'),
('Pepe', 'Defesa Central', '~/images/pepe.jpg'),
('Otávio', 'Médio Ofensivo', '~/images/otavio.jpg');

-- Troféus
INSERT INTO Trofeus (Nome, Ano, Imagem) VALUES
('Champions League', 2004, '~/images/champions.jpg'),
('Liga Europa', 2011, '~/images/ligaeuropa.jpg'),
('Supertaça Europeia', 1987, '~/images/supertaca.jpg');

-- História
INSERT INTO Historia (Titulo, Conteudo, Imagem) VALUES
('História do FC Porto', 'O Futebol Clube do Porto foi fundado a 28 de setembro de 1893, tornando-se um dos clubes mais antigos e bem-sucedidos de Portugal. Ao longo da sua história, o clube conquistou inúmeros títulos nacionais e internacionais, consolidando-se como um símbolo de excelência desportiva.', '~/images/porto_historia.jpg');

-- Estádio
INSERT INTO Estadio (Nome, Descricao, Imagem) VALUES
('Estádio do Dragão', 'Inaugurado em 2003, o Estádio do Dragão é a casa do Futebol Clube do Porto. Com capacidade para mais de 50.000 adeptos, é considerado um dos estádios mais modernos de Portugal.', '~/images/estadio1.jpg');

-- Contactos
INSERT INTO Contactos (Tipo, Valor) VALUES
('Email', 'info@fcporto.pt'),
('Telefone', '+351 225 074 100'),
('Morada', 'Estádio do Dragão, Via Futebol Clube do Porto, 4350-415 Porto, Portugal');
GO
