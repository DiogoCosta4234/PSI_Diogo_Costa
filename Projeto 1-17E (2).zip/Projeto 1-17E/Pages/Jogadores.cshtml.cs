using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Projeto_1_17E.Pages
{
    public class JogadoresModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
