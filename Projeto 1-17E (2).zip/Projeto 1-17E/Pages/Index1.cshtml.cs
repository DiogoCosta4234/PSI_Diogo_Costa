using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Projeto_1_17E.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
