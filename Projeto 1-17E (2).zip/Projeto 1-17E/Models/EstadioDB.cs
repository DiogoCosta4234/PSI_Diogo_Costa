﻿namespace Projeto_1_17E.Models
{
    public class EstadioDB
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Descricao { get; set; }
        public string? Imagem { get; set; }
    }
}
