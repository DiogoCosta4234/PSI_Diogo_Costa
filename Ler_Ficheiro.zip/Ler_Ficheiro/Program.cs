﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ler_Ficheiro
{

    class Program
    {
        static void Main()
        {
            string caminho = "C:\\Users\\Admin\\Desktop\\PSI - C#\\Ler_Ficheiro\\ficheiro.txt";

            try
            {

                if (File.Exists(caminho))
                {
                    
                    string conteudo = File.ReadAllText(caminho);
                    Console.WriteLine("Conteúdo do ficheiro:");
                    Console.WriteLine(conteudo);
                }
                else
                {
                    Console.WriteLine("Erro: O ficheiro 'ficheiro.txt' não existe");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao tentar ler o ficheiro:");
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("\nExecução terminada.");
            }
        } 
    }
}
