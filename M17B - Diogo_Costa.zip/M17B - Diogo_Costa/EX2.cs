﻿using System;

class Program
{
    static void Main()
    {
        int[] numeros = new int[8]; 
        int numero;
        string input;

        for (int i = 0; i < numeros.Length; i++)
        {
            bool valido = false;

            while (!valido)
            {
                Console.Write($"Introduza o número inteiro ({i + 1}): ");
                input = Console.ReadLine();

               
                if (int.TryParse(input, out numero))
                {
                    numeros[i] = numero;
                    valido = true;
                }
                else
                {
                    Console.WriteLine("Valor inválido | Introduza um número inteiro");
                }
            }
        }

        Console.WriteLine("Números Inseridos:");
        foreach (int n in numeros)
        {
            Console.WriteLine(n);
        }
    }
}