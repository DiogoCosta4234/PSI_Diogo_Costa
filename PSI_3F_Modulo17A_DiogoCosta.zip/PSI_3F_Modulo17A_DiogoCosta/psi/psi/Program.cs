﻿// See https://aka.ms/new-console-template for more information
using System.Text;


//tring endereço = "rua 1";
//int idade = 25;
//decimal salario =(decimal)1050.35;
//bool maiorDEidade = false;


//if (nome == null)
//{
//  Console.WriteLine("O nome informado nao está correto ");}
//else if (nome.Length < 3)

// Console.WriteLine("O nome deve conter mais de 3 caracteres.");}
//else{
using System;
using psi.Modelos;
using psi.Excecoes; // importa as tuas classes

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Bem-vindo ao seu sistema de corrida!");
        Console.Write("Qual o seu nome: ");
        string nomeDigitado = Console.ReadLine();

        var usuario = new Usuario(nomeDigitado); // construtor exige nome

        try
        {
            usuario.Validador(); // valida o nome
        }

        catch (NegocioException ex)
        { 
        Console.WriteLine($"{ex.codigo} + {ex.Message}");  
            return;  
        }

        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao validar o nome: {ex.Message}");
            return;
        }

        Console.Write("Agora informe a sua idade: ");
        int.TryParse(Console.ReadLine(), out int idade);
        usuario.Idade = idade;

        Console.Write($"Certo {usuario.Nome}. Qual é a sua meta de corrida para esse ano? ");
        decimal.TryParse(Console.ReadLine(), out decimal objetivo);
        usuario.Meta = new Meta { Objetivo = objetivo };

        Console.Write("Informe o mês atual (número de 1 a 12): ");
        int.TryParse(Console.ReadLine(), out int mesAtual);
        if (mesAtual < 1 || mesAtual > 12)
        {
            Console.WriteLine("Mês inválido. Encerrando o programa.");
            return;
        }

        Console.WriteLine($"Certo {usuario.Nome}, informe quantos KM correu nos meses anteriores:");

        for (int i = 1; i <= mesAtual; i++)
        {
            Console.Write($"KM corridos no mês {i}: ");
            decimal.TryParse(Console.ReadLine(), out decimal distanciaNoMes);

            usuario.Meta.AdicionarDistanciaPercorridaMes(i, distanciaNoMes);

            // Feedback simples
            if (distanciaNoMes < 5)
                Console.WriteLine("Pode correr mais!");
            else if (distanciaNoMes < 15)
                Console.WriteLine("Está a correr bastante bem!");
            else
                Console.WriteLine("Excelente trabalho!");
        }

        Console.WriteLine("\nResumo mensal:");
        foreach (var item in usuario.Meta.DistanciaPorMes)
        {
            Console.WriteLine($"Mês {item.Key}: {item.Value} km");
        }

        Console.WriteLine($"\n{usuario.Nome}, percorreu um total de {usuario.Meta.DistanciaPercorrida} km!");
        Console.WriteLine($"Faltam {usuario.Meta.FaltaParaObjetivo} km para atingir a sua meta!");
    }
}
