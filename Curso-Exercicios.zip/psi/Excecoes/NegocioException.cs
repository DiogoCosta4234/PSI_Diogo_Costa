﻿

namespace psi.Excecoes
{
    public  class NegocioException : Exception
    {

        public NegocioException(int codigo , string message): base (message){

            codigo = codigo;
           
        
        }

        public int codigo { get; }
    }   
}
