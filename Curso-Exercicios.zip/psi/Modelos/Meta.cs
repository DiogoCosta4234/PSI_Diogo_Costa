﻿using System.Collections.Generic;
using System.Linq;

namespace psi.Modelos
{
    public class Meta
    {
        public decimal Objetivo { get; set; }
        public Dictionary<int, decimal> DistanciaPorMes { get; private set; } = new Dictionary<int, decimal>();

        public void AdicionarDistanciaPercorridaMes(int mes, decimal distancia)
        {
            if (DistanciaPorMes.ContainsKey(mes))
                DistanciaPorMes[mes] += distancia;
            else
                DistanciaPorMes[mes] = distancia;
        }

        public decimal DistanciaPercorrida => DistanciaPorMes.Values.Sum();

        public decimal FaltaParaObjetivo => Objetivo - DistanciaPercorrida;
    }

}