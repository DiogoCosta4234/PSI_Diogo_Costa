﻿

namespace psi.Modelos
{


    internal class UsuarioCorredor : Usuario
    {
        public UsuarioCorredor(string nome) : base(nome) { }


        public decimal Velocidade { get; set; }
    }

}
