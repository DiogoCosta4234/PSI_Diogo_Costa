﻿using psi.Excecoes;

namespace psi.Modelos
{
    public struct Nome
    {
        private readonly string _nome;

        private Nome(string nome)
        {
            _nome = nome;
        }

        public override string ToString()
        {
            return _nome;
        }

        // conversão implícita de string para Nome
        public static implicit operator Nome(string nome)
        {
            return new Nome(nome);
        }

        public class Validador
        {
            private string nome;

            public Validador(string nome)
            {
                this.nome = nome;
            }

            public void Validar()
            {
                if (nome == null)
                    throw new NegocioException(1, "O nome informado não está correto.");
                else if (nome.Length < 3)
                    throw new NegocioException(2,"O nome deve conter mais do que 3 caracteres.") ;
            }
        }

    }
}
