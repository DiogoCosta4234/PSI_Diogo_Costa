﻿namespace psi.Modelos
{
    public class Usuario
    {
        public Usuario(string nome)
        {
            Nome = nome; // atribui ao property Nome
        }

        public Nome Nome { get; }      // Propriedade só leitura (definida no construtor)
        public int Idade { get; set; }
        public Meta Meta { get; set; }

        public bool Validador()
        {
            if (Nome.ToString() == null || string.IsNullOrWhiteSpace(Nome.ToString()))
            {
                Console.WriteLine("O nome informado não está correto.");
                return false;
            }
            else if (Nome.ToString().Length < 3)
            {
                Console.WriteLine("O nome deve conter mais de 3 caracteres.");
                return false;
            }
            return true;
        }
    }
}
   

