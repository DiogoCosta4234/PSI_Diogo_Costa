﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto3_4CRUD
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void alunoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.alunoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.database2DataSet);
            DialogResult resposta = MessageBox.Show(
        "Desejas guardar as alterações feitas aos dados?",
        "Confirmar gravação",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question
    );

            if (resposta == DialogResult.Yes)
            {
                try
                {
                    this.Validate();
                    this.alunoBindingSource.EndEdit();
                    this.tableAdapterManager.UpdateAll(this.database2DataSet);

                    MessageBox.Show(
                        "As alterações foram guardadas com sucesso!",
                        "Guardar",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Ocorreu um erro ao guardar as alterações:\n" + ex.Message,
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            else
            {
                MessageBox.Show(
                    "A gravação foi cancelada.",
                    "Cancelado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'database2DataSet.Aluno'. Você pode movê-la ou removê-la conforme necessário.
            this.alunoTableAdapter.Fill(this.database2DataSet.Aluno);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1(); // Cria uma nova instância do Form1
            form1.Show();              // Mostra o Form1
            this.Close();
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            DialogResult resposta = MessageBox.Show(
          "Tens a certeza que queres eliminar este aluno?",
          "Confirmar eliminação",
          MessageBoxButtons.YesNo,
          MessageBoxIcon.Warning
      );

            if (resposta == DialogResult.Yes)
            {
                try
                {
                    // Remove o registo atual
                    alunoBindingSource.RemoveCurrent();

                    // Atualiza a base de dados
                    this.tableAdapterManager.UpdateAll(this.database2DataSet);

                    MessageBox.Show(
                        "O aluno foi eliminado com sucesso.",
                        "Eliminação concluída",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Ocorreu um erro ao eliminar o aluno:\n" + ex.Message,
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            else
            {
                MessageBox.Show(
                    "A eliminação foi cancelada.",
                    "Cancelado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            DialogResult resposta = MessageBox.Show(
       "Desejas adicionar um novo aluno?",
       "Confirmar adição",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Question
   );

            if (resposta == DialogResult.Yes)
            {
                alunoBindingSource.AddNew(); // Cria novo registo
                MessageBox.Show(
                    "Novo aluno adicionado. Preenche os campos antes de guardar.",
                    "Adicionar aluno",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
            else
            {
                MessageBox.Show(
                    "A adição foi cancelada.",
                    "Cancelado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.BackColor == Color.White)
            {
                this.BackColor = Color.FromArgb(45, 45, 48); // Modo escuro
                foreach (Control c in this.Controls)
                    c.ForeColor = Color.White;
            }
            else
            {
                this.BackColor = Color.White; // Modo claro
                foreach (Control c in this.Controls)
                    c.ForeColor = Color.Black;
            }
        }
    }
    }


