﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto3_4CRUD
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void inscricoesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.inscricoesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.database2DataSet);
            DialogResult resposta = MessageBox.Show(
        "Desejas guardar as alterações feitas às inscrições?",
        "Confirmar gravação",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question
    );

            if (resposta == DialogResult.Yes)
            {
                try
                {
                    this.Validate();
                    this.inscricoesBindingSource.EndEdit();
                    this.tableAdapterManager.UpdateAll(this.database2DataSet);

                    MessageBox.Show(
                        "As alterações foram guardadas com sucesso!",
                        "Guardar",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Ocorreu um erro ao guardar as alterações:\n" + ex.Message,
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            else
            {
                MessageBox.Show(
                    "A gravação foi cancelada.",
                    "Cancelado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'database2DataSet.Inscricoes'. Você pode movê-la ou removê-la conforme necessário.
            this.inscricoesTableAdapter.Fill(this.database2DataSet.Inscricoes);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1(); // Cria uma nova instância do Form1
            form1.Show();              // Mostra o Form1
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            DialogResult resposta = MessageBox.Show(
       "Tens a certeza que queres eliminar esta inscrição?",
       "Confirmar eliminação",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Warning
   );

            if (resposta == DialogResult.Yes)
            {
                try
                {
                    inscricoesBindingSource.RemoveCurrent(); // Remove a inscrição selecionada
                    this.tableAdapterManager.UpdateAll(this.database2DataSet); // Atualiza a BD

                    MessageBox.Show(
                        "A inscrição foi eliminada com sucesso.",
                        "Eliminação concluída",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Ocorreu um erro ao eliminar a inscrição:\n" + ex.Message,
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            else
            {
                MessageBox.Show(
                    "A eliminação foi cancelada.",
                    "Cancelado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            DialogResult resposta = MessageBox.Show(
      "Desejas adicionar uma nova inscrição?",
      "Confirmar adição",
      MessageBoxButtons.YesNo,
      MessageBoxIcon.Question
  );

            if (resposta == DialogResult.Yes)
            {
                inscricoesBindingSource.AddNew(); // Cria um novo registo
                MessageBox.Show(
                    "Nova inscrição adicionada. Preenche os campos antes de guardar.",
                    "Adicionar inscrição",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
            else
            {
                MessageBox.Show(
                    "A adição foi cancelada.",
                    "Cancelado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.BackColor == Color.White)
            {
                this.BackColor = Color.FromArgb(45, 45, 48); // Modo escuro
                foreach (Control c in this.Controls)
                    c.ForeColor = Color.White;
            }
            else
            {
                this.BackColor = Color.White; // Modo claro
                foreach (Control c in this.Controls)
                    c.ForeColor = Color.Black;
            }
        }
    }
    }

