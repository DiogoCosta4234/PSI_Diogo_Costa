﻿namespace EscolaApp
{
    partial class Menu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bntalunos = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.btcurso = new System.Windows.Forms.Button();
            this.btnincrição = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bntalunos
            // 
            this.bntalunos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntalunos.Location = new System.Drawing.Point(117, 176);
            this.bntalunos.Name = "bntalunos";
            this.bntalunos.Size = new System.Drawing.Size(94, 43);
            this.bntalunos.TabIndex = 2;
            this.bntalunos.Text = "Alunos";
            this.bntalunos.UseVisualStyleBackColor = true;
            this.bntalunos.Click += new System.EventHandler(this.button6_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(200, 122);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(179, 27);
            this.label8.TabIndex = 3;
            this.label8.Text = "Programa Cursos";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // btcurso
            // 
            this.btcurso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcurso.Location = new System.Drawing.Point(251, 176);
            this.btcurso.Name = "btcurso";
            this.btcurso.Size = new System.Drawing.Size(94, 44);
            this.btcurso.TabIndex = 1;
            this.btcurso.Text = "Cursos";
            this.btcurso.UseVisualStyleBackColor = true;
            this.btcurso.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnincrição
            // 
            this.btnincrição.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnincrição.Location = new System.Drawing.Point(369, 176);
            this.btnincrição.Name = "btnincrição";
            this.btnincrição.Size = new System.Drawing.Size(94, 44);
            this.btnincrição.TabIndex = 4;
            this.btnincrição.Text = "Incrições";
            this.btnincrição.UseVisualStyleBackColor = true;
            // 
            // Menu
            // 
            this.ClientSize = new System.Drawing.Size(564, 449);
            this.Controls.Add(this.btnincrição);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.bntalunos);
            this.Controls.Add(this.btcurso);
            this.Name = "Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private EscolaDataSet escolaDataSet;
        private System.Windows.Forms.BindingSource alunosBindingSource;
        private EscolaDataSetTableAdapters.AlunosTableAdapter alunosTableAdapter;
        private EscolaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator alunosBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton alunosBindingNavigatorSaveItem;
        private System.Windows.Forms.BindingSource cursosBindingSource;
        private EscolaDataSetTableAdapters.CursosTableAdapter cursosTableAdapter;
        private System.Windows.Forms.BindingSource inscricoesBindingSource;
        private EscolaDataSetTableAdapters.InscricoesTableAdapter inscricoesTableAdapter;
        private System.Windows.Forms.Button enviar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnCursos;
        private System.Windows.Forms.Button btnIncrições;
        private System.Windows.Forms.Button btnAlunos;
        private System.Windows.Forms.Label Menu;
        private System.Windows.Forms.Button btnaluno;
        private System.Windows.Forms.Button btncurso;
        private System.Windows.Forms.Button btninscrição;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button bntalunos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btcurso;
        private System.Windows.Forms.Button btnincrição;
    }
}

