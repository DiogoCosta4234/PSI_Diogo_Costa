﻿using inscricao;
using System;
using System.Windows.Forms;

namespace EscolaApp
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void btnAlunos_Click(object sender, EventArgs e)
        {
            FormAluno formAluno = new FormAluno();
            formAluno.Show(); // Abre a janela de alunos
            this.Hide();
        }

        private void btnCursos_Click(object sender, EventArgs e)
        {
            
        }

        private void btnInscricoes_Click(object sender, EventArgs e)
        {
           
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
