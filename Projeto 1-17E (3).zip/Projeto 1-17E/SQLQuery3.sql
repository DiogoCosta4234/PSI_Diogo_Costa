﻿/* 1. Limpa os dados antigos para evitar duplicação ou erros de formato */
DELETE FROM Estadio;

/* 2. Insere os dados divididos corretamente por colunas */
INSERT INTO Estadio (Titulo, Conteudo, Imagem)
VALUES 
(
    'Estádio do Dragão', 
    'Inaugurado em 2003, o Estádio do Dragão é a casa do Futebol Clube do Porto. Com capacidade para mais de 50.000 adeptos, é considerado um dos estádios mais modernos de Portugal. O estádio recebe jogos da liga portuguesa, competições europeias e eventos especiais.', 
    'estadio1.jpg'
),
(
    'Infraestruturas e Atmosfera', 
    'O estádio possui infraestruturas de topo, incluindo museu, lojas oficiais e zonas VIP. É conhecido pela atmosfera incrível criada pelos adeptos, especialmente nos jogos mais importantes. O emblema do dragão e as cores azul e branco tornam a experiência única.', 
    'estadio2.jpg'
);

/* 3. Verifica se os dados foram inseridos corretamente */
SELECT * FROM Estadio;