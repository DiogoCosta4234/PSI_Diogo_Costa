﻿/* 1. Limpa os dados antigos */
DELETE FROM Trofeus;

/* 2. Reinicia o ID para começar no 1 */
DBCC CHECKIDENT ('Trofeus', RESEED, 0);

/* 3. Insere os dados formatados corretamente */
INSERT INTO Trofeus (Nome, Descricao, Imagem, Quantidade)
VALUES 
(
    'Champions League', 
    'A glória máxima conquistada em 1987 (Viena) e 2004 (Gelsenkirchen).', 
    'champions.jpg', 
    2
),
(
    'Liga Europa', 
    'Vencida em 2003 (Sevilha) e 2011 (Dublim). O orgulho europeu do Dragão.', 
    'ligaeuropa.jpg', 
    2
),
(
    'Supertaça Europeia', 
    'Conquistada em 1987 contra o Ajax. O único clube português com este título.', 
    'supertaca.jpg', 
    1
);

/* 4. Verifica se os nomes das imagens batem certo com a tua pasta */
SELECT * FROM Trofeus;