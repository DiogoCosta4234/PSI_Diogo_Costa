﻿/* 1. Limpa os nomes para garantir que batem com os ficheiros na pasta wwwroot/images */
UPDATE Trofeus SET Imagem = '~/images/champions.jpg' WHERE Nome LIKE '%Champions%';
UPDATE Trofeus SET Imagem = '~/images/ligaeuropa.jpg' WHERE Nome LIKE '%Europa%';
UPDATE Trofeus SET Imagem = '~/images/supertaca.jpg' WHERE Nome LIKE '%Supertaça%';

/* 2. Verifica se existem espaços nos nomes que possam causar erro */
SELECT Id, Nome, Imagem FROM Trofeus;