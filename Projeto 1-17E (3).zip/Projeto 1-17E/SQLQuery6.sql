﻿/* Limpa os caminhos para garantir que batem com os nomes dos ficheiros na pasta */
UPDATE Trofeus SET Imagem = '~/images/champions.jpg' WHERE Nome LIKE '%Champions%';
UPDATE Trofeus SET Imagem = '~/images/ligaeuropa.jpg' WHERE Nome LIKE '%Europa%';
UPDATE Trofeus SET Imagem = '~/images/supertaca.jpg' WHERE Nome LIKE '%Supertaça%';

/* Verifique se os dados foram atualizados */
SELECT * FROM Trofeus;