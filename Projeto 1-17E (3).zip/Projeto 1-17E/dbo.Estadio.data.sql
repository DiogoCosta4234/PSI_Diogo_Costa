﻿SET IDENTITY_INSERT [dbo].[Estadio] ON
INSERT INTO [dbo].[Estadio] ([Id], [Nome], [Descricao], [Imagem]) VALUES (1, N'', N'', N'')
SET IDENTITY_INSERT [dbo].[Estadio] OFF
