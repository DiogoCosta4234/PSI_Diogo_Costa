﻿namespace Projeto_1_17E.Models
{
    public class Contacto
    {
        public int Id { get; set; }
        public string Tipo { get; set; } = null!; // Ex: "Telefone", "Email"
        public string Valor { get; set; } = null!; // Ex: "910000000", "geral@fcporto.pt"
    }
}