﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Projeto_1_17E.Models
{
    [Table("Historia")] // Garante a ligação correta à tabela da tua imagem
    public class Historia
    {
        public int Id { get; set; }
        public string Titulo { get; set; } = null!;
        public string Conteudo { get; set; } = null!;
        public string? Imagem { get; set; }
    }
}