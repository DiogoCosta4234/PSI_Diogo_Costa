﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Projeto_1_17E.Models
{
    [Table("Jogadores")]
    public class Jogador
    {
        public int Id { get; set; }
        public string Nome { get; set; } = null!;

        // Mudamos de Descricao para Posicao
        public string Posicao { get; set; } = null!;

        public string? Imagem { get; set; }
    }
}