﻿using Microsoft.EntityFrameworkCore;

namespace Projeto_1_17E.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Estadio> Estadio { get; set; }
        public DbSet<Jogador> Jogadores { get; set; }
        public DbSet<Historia> Historias { get; set; }

        // Esta linha resolve o erro do AppDbContext
        public DbSet<Trofeu> Trofeus { get; set; }
    }
}