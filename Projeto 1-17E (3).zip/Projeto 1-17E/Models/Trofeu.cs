﻿namespace Projeto_1_17E.Models
{
    public class Trofeu
    {
        public int Id { get; set; }
        public string Nome { get; set; } = null!;
        public int Ano { get; set; }
        public string Imagem { get; set; } = null!;
    }
}