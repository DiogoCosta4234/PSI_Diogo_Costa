﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Projeto_1_17E.Models
{
    [Table("Estadio")]
    public class Estadio
    {
        public int Id { get; set; }
        public string Nome { get; set; } = null!;
        public string Descricao { get; set; } = null!;
        public string? Imagem { get; set; }
    }
}