using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Projeto_1_17E.Models;

namespace Projeto_1_17E.Pages
{
    public class JogadoresModel : PageModel
    {
        private readonly AppDbContext _context;

        public JogadoresModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<Jogador> ListaJogadores { get; set; } = default!;

        public async Task OnGetAsync()
        {
            // Busca os dados da tabela Jogadores
            ListaJogadores = await _context.Jogadores.ToListAsync();
        }
    }
}