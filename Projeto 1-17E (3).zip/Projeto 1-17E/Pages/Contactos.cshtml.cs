using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Projeto_1_17E.Pages
{
    public class ContactosModel : PageModel
    {
        [TempData]
        public string? MensagemSucesso { get; set; }

        public void OnGet() { }

        public IActionResult OnPost(string nome, string email, string assunto, string mensagem)
        {
            // Simula��o de envio
            MensagemSucesso = $"Obrigado {nome}! A sua mensagem foi enviada com sucesso.";
            return RedirectToPage();
        }
    }
}