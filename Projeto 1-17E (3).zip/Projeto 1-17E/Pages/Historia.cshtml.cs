using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Projeto_1_17E.Models;

namespace Projeto_1_17E.Pages
{
    public class HistoriaModel : PageModel
    {
        private readonly AppDbContext _context;

        public HistoriaModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<Historia> ListaHistoria { get; set; } = default!;

        public async Task OnGetAsync()
        {
            // Vai buscar todos os registos da tabela Historia no SQL
            ListaHistoria = await _context.Historias.ToListAsync();
        }
    }
}