using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Projeto_1_17E.Models;

namespace Projeto_1_17E.Pages
{
    public class TrofeusModel : PageModel
    {
        private readonly AppDbContext _context;

        public TrofeusModel(AppDbContext context)
        {
            _context = context;
        }

        // Esta linha � obrigat�ria para o HTML funcionar
        public IList<Trofeu> ListaTrofeus { get; set; } = default!;

        public async Task OnGetAsync()
        {
            // Busca os dados da tabela Trofeus
            // Certifique-se de que no AppDbContext o nome � 'Trofeus'
            ListaTrofeus = await _context.Trofeus.ToListAsync();
        }
    }
}