﻿/* Limpa os dados para não repetir */
DELETE FROM Estadio;

/* Insere usando os nomes Reais das tuas colunas: Nome e Descricao */
INSERT INTO Estadio (Nome, Descricao, Imagem)
VALUES 
(
    'Estádio do Dragão', 
    'Inaugurado em 2003, o Estádio do Dragão é a casa do Futebol Clube do Porto. Com capacidade para mais de 50.000 adeptos, é considerado um dos estádios mais modernos de Portugal.', 
    'estadio1.jpg'
),
(
    'Infraestruturas e Atmosfera', 
    'O estádio possui infraestruturas de topo, incluindo museu, lojas oficiais e zonas VIP. É conhecido pela atmosfera incrível criada pelos adeptos, especialmente nos jogos mais importantes.', 
    'estadio2.jpg'
);

/* Verifica o resultado */
SELECT * FROM Estadio;