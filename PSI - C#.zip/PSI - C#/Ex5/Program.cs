﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX5
{
    using System;

    class OperacaoInvalidaException : Exception
    {
        public OperacaoInvalidaException(string msg) : base(msg) { }
    }

    class Program
    {
        static double LerNumero(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                try
                {
                    return double.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Entrada inválida.");
                }
            }
        }

        static int LerOperacao()
        {
            Console.WriteLine("1 - Soma");
            Console.WriteLine("2 - Subtração");
            Console.WriteLine("3 - Multiplicação");
            Console.WriteLine("4 - Divisão");

            while (true)
            {
                Console.Write("Operação (1-4): ");
                try
                {
                    int op = int.Parse(Console.ReadLine());
                    if (op >= 1 && op <= 4) return op;
                    throw new OperacaoInvalidaException("Operação inválida.");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Entrada inválida.");
                }
            }
        }

        static void Main()
        {
            try
            {
                int op = LerOperacao();
                double a = LerNumero("Primeiro número: ");
                double b = LerNumero("Segundo número: ");

                switch (op)
                {
                    case 1: Console.WriteLine(a + b); break;
                    case 2: Console.WriteLine(a - b); break;
                    case 3: Console.WriteLine(a * b); break;
                    case 4:
                        if (b == 0) Console.WriteLine("Divisão por zero.");
                        else Console.WriteLine(a / b);
                        break;
                }
            }
            catch (OperacaoInvalidaException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}