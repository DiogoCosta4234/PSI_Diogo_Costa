﻿using System;

namespace Video_Aula
{
    internal class Program
    {
        static void Main(string[] args)
        {

            decimal x, y, r;

            try
            {
                Console.WriteLine("Digite o valor de x:");
                x = Convert.ToDecimal(Console.ReadLine());

                Console.WriteLine("Digite o valor de y:");
                y = Convert.ToDecimal(Console.ReadLine());

                if (x < 0 || y < 0)
                {
                    throw new ArgumentException("Não sao aceitos números negativos");
                }

                r = x / y;

                Console.WriteLine($"r = {r:N}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Número em formato inválido.");
                Console.WriteLine($"Mensagem de erro: {ex.Message}");
            }
            catch (DivideByZeroException ex)
            {

                Console.WriteLine("Não é possível dividir por zero");
                Console.WriteLine($"Mensagem de erro : {ex.Message}");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Não são aceitos números negativos.");
                Console.WriteLine($"Mensagem de erro: {ex.Message}");
            }
            catch (OverflowException ex)
            {
                Console.WriteLine("Número demasiado grande ou pequeno.");
                Console.WriteLine($"Mensagem de erro: {ex.Message}");
            }
            catch (Exception ex) // GENÉRICO — sempre o último
            {
                Console.WriteLine($"Erro genérico : {ex.Message}");
            }

            Console.Write("Fim do Programa");
        }
    }
}
