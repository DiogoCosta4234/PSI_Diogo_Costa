﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1;
            int num2;

            try
            {
                Console.WriteLine("Digite o primeiro numero: ");
                num1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Digite o segundo numero: ");
                num2 = Convert.ToInt32(Console.ReadLine());
                int resultado = num1 / num2;
                Console.WriteLine("A divisao dos seus números é: " + resultado);

            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Não pode dividir algum numero por 0");
                throw;

            }
        }
    }
}
