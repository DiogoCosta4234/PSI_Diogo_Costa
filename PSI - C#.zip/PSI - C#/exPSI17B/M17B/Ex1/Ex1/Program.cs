﻿using System;           
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex1
{
    internal class Program
    {
        static void checkAge(int age)
        {
            if (age<18)
            {
                throw new ArithmeticException("Acesso negado- Precisas ter 18 anos ou mais");
            }
            else
            {
                Console.WriteLine("Acesso concedido - Bem-vindo");
            }
        }
        static void Main(string [] args)
        {
            checkAge(27);
            Console.ReadKey();
        }
       
        }
}
