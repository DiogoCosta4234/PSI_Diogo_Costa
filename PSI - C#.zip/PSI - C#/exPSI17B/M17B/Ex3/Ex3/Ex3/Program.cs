﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex3
 {
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira: fim = código terminar");
            Console.WriteLine("O seu nome tem de ter mais de 3 caracteres!!!");
            string nome = "";

            while (nome != "fim") {
                Console.WriteLine("Digite o seu nome");
                nome = Console.ReadLine();
                try
                {
                    {
                        if (nome.Length < 3 || string.IsNullOrWhiteSpace(nome))
                        {
                            Console.WriteLine("Nome inválido");
                            Console.WriteLine("Fim do programa");
                            break;
                        }
                     
                        if (!string.IsNullOrWhiteSpace(nome) || nome.Length > 3) {

                            Console.WriteLine("Nome Válido");
                            Console.WriteLine(nome);

                        }
                    } }

                catch (Exception ex)
                {
                    Console.WriteLine("Erro: " + ex.Message);
                    throw;
                }
            }
        }
       
    }
}

